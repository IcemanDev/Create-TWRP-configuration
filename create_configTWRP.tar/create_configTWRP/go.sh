#!/bin/bash

#xterm -maximized -geometry 46x18 -fn *-fixed-*-*-*-20-* -title 'Create TWRP configuration by IceMan' $PWD/crear.sh
#gnome-terminal --maximize -x bash -c "$PWD/crear.sh; bash"
gnome-terminal --geometry=80x100 -x bash -c "$PWD/.bin/cfgtwrp.cfg; bash"